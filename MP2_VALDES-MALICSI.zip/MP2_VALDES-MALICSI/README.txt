﻿​​# `README: SIP and RTP Communication Program`


`Justine Valdes & Patrick Malicsi`


## `Quick Overview`


`This project implements a SIP (Session Initiation Protocol) and RTP (Real-Time Transport Protocol) communication system. It includes a sender and receiver program that establishes a call using SIP for signaling and RTP for media transmission.`


## `Key Features`


* `The sender file starts a SIP call and streams audio using RTP.` 
* `The receiver listens for a SIP request and answers the SIP call and plays the received audio in real-time.` 
* `Supports SIP operations such as INVITE, ACK, and BYE.` 
* `Handles RTP packet creation, transmission, and reception.` 


---


## **`Requirements`**


* `Python 3.1 or later` 
* `socket, struct, threading, wave, and pyaudio modules` 
* `Terminal` 
* `Audio file in .wav format (for the sender)` 




### **`Running the Sender`**


1. `Open a terminal and navigate to the project directory using the cd command.` 
2. `Run the following command:` 
  ```cd *directory where files are located*
  python sender.py
3. Enter the name of the .wav file to play when prompted.
4. The sender will initiate a SIP call, stream the audio using RTP, and send RTCP reports.
________________


Running the Receiver
1. Open another terminal and navigate to the project directory using the cd command.
2. Run the following command:
3. python receiver.py
4. The receiver will wait for a SIP INVITE from the sender.
5. Once the call is established, the receiver will play the received audio in real-time and send RTCP reports.
________________


Error Handling
The program implements error handling for the following scenarios:
* File Not Found: If the specified audio file does not exist, the sender will display an error message.
* Timeouts: If there is no SIP response is received within 5 seconds, the sender will terminate the call.
* Invalid Inputs & Errors:  If a client receives a SIP error (4xx, 5xx), it should log or handle gracefully.
*  
________________


Example Test Cases
Test Case 1: Successful Call Establishment and Audio Transmission
Sender Input:
Enter the name of the .wav file to play (e.g., audio.wav): test_audio.wav


Expected Output (Sender):


Establishing SIP call...
SIP call established.
Playing audio from file: test_audio.wav.
Sent RTP packet 1, timestamp 160
Sent RTP packet 2, timestamp 320
…
== == == == == == == == == == == == == 
==== == ==  STREAM ENDED === == == 
== == == == == == == == == == == == == 


The call has been terminated.


Expected Output (Receiver):


Waiting for SIP INVITE...
 Remote IP = 127.0.0.1, Remote Port = 5004
SIP call established.
Receiving RTP audio...
End of RTP stream detected.
The call has been terminated.


Test Case 2: File Not Found
Sender Input:


Enter the name of the wav file to play (e.g., audio.wav): missing_audio.wav


Expected Output (Sender):


Error: Audio file 'missing_audio.wav' not found.
The call has been terminated.


Test Case 3: Timeout Waiting for SIP Response


Sender Input:


Enter the name of the wav file to play (e-g., audio.wav): test_audio.wav


Expected Output (Sender):


Establishing SIP call...
Timeout waiting for SIP response.
The call has been terminated.


Test Case 4: Successful RTCP Report Transmission


Expected Output (Sender):


RTCP Sender Report Sent!
...


Expected Output (Receiver):


RTCP Receiver Report!
..=