import socket
import uuid
import wave
import time
import struct
import random
import threading

class HandlingSIPinSender:
    def __init__(self, local_ip, local_port, remote_ip, remote_port):
        self.local_ip = local_ip
        self.local_port = local_port
        self.remote_ip = remote_ip
        self.remote_port = remote_port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((self.local_ip, self.local_port))
        self.call_id = str(uuid.uuid4())  # Generate a unique Call-ID

    def SIP_HANDSHAKE(self):
        # SDP Negotiation (RFC 4566)
        SDP = f"v=0\r\n"
        SDP += f"o=- 0 0 IN IP4 {self.local_ip}\r\n"
        SDP += f"s=VoIP Call\r\n"
        SDP += f"c=IN IP4 {self.local_ip}\r\n"
        SDP += f"t=0 0\r\n"
        SDP += f"m=audio {self.local_port} RTP/AVP 0\r\n"
        SDP += f"a=rtpmap:0 PCMU/8000\r\n"

        # INVITE (RFC 3261)
        InviteMessage = f"INVITE SIP:{self.remote_ip}:{self.remote_port} SIP/2.0\r\n"
        InviteMessage += f"Via: SIP/2.0/UDP {self.local_ip}:{self.local_port}\r\n"
        InviteMessage += f"To: <sip:{self.remote_ip}:{self.remote_port}>\r\n"
        InviteMessage += f"From: <sip:{self.local_ip}:{self.local_port}>\r\n"
        InviteMessage += f"Call-ID: {self.call_id}\r\n"
        InviteMessage += "CSeq: 1 INVITE\r\n"
        InviteMessage += "Content-Type: application/sdp\r\n"
        InviteMessage += f"Content-Length: {len(SDP)}\r\n\r\n"
        InviteMessage += SDP
        
        # Send INVITE packet
        self.sock.sendto(InviteMessage.encode(), (self.remote_ip, self.remote_port))

        # Wait for SIP response
        try:
            self.sock.settimeout(5)  
            response, _ = self.sock.recvfrom(1024)
            response_str = response.decode()

            if "200 OK" in response_str:
                # Parsing SDP from the response
                sdp_start = response_str.find("\r\n\r\n") + 4 
                sdp = response_str[sdp_start:]

                # Parse the c= line (connection information)
                for line in sdp.splitlines():
                    if line.startswith("c="):
                        self.remote_ip = line.split()[2] # IP address
                    elif line.startswith("m="):
                        self.remote_port = int(line.split()[1])  # PORT

                print(f"Parsed SDP: Remote IP = {self.remote_ip}, Remote Port = {self.remote_port}")

                # make and send the ACK packet
                ack_message = f"ACK sip:{self.remote_ip}:{self.remote_port} SIP/2.0\r\n"
                ack_message += f"Via: SIP/2.0/UDP {self.local_ip}:{self.local_port}\r\n"
                ack_message += f"To: <sip:{self.remote_ip}:{self.remote_port}>\r\n"
                ack_message += f"From: <sip:{self.local_ip}:{self.local_port}>\r\n"
                ack_message += f"Call-ID: {self.call_id}\r\n"
                ack_message += "CSeq: 1 ACK\r\n"
                ack_message += "Content-Length: 0\r\n\r\n"
                self.sock.sendto(ack_message.encode(), (self.remote_ip, self.remote_port))
                print("SIP call established.")
            elif response_str.startswith("4") or response_str.startswith("5"):
                print(f"SIP error received: {response_str.strip()}")
            else:
                print(f"Unexpected SIP response: {response_str.strip()}")

        except socket.timeout:
            print("Timeout waiting for SIP response.")
        except Exception as e:
            print(f"Error during SIP call: {e}")

    def end_call(self):
        # make and send the BYE packet
        ByeMessage = f"BYE sip:{self.remote_ip}:{self.remote_port} SIP/2.0\r\n"
        ByeMessage += f"Via: SIP/2.0/UDP {self.local_ip}:{self.local_port}\r\n"
        ByeMessage += f"To: <sip:{self.remote_ip}:{self.remote_port}>\r\n"
        ByeMessage += f"From: <sip:{self.local_ip}:{self.local_port}>\r\n"
        ByeMessage += f"Call-ID: {self.call_id}\r\n"
        ByeMessage += "CSeq: 2 BYE\r\n"
        ByeMessage += "Content-Length: 0\r\n\r\n"
        self.sock.sendto(ByeMessage.encode(), (self.remote_ip, self.remote_port))
        print("BYE message sent.")
        print("Waiting other client's BYE message...")

        # other clients BYE message
        try:
            self.sock.settimeout(5) 
            while True:
                message, addr = self.sock.recvfrom(1024)
                if b"BYE" in message:
                    print("BYE message received from client 2.")
                    break
        except socket.timeout:
            print("Timeout waiting for BYE message from client 2.")

        # close the socket
        self.sock.close()

class HandlingRTPinSender:
    def __init__(self, audio_file, remote_ip, remote_port):
        self.audio_file = audio_file
        self.remote_ip = remote_ip
        self.remote_port = remote_port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sequence_number = 0
        self.timestamp = 0
        self.ssrc = random.randint(0, 2**32 - 1)  # dynamic 

    def build_rtp_header(self):
        # RTP Header (RFC 3550)
        version = 2
        padding = 0
        extension = 0
        cc = 0
        marker = 0
        payload_type = 0
        header = (
            (version << 6) | (padding << 5) | (extension << 4) | cc,
            (marker << 7) | payload_type,
            self.sequence_number,
            self.timestamp,
            self.ssrc
        )
        # Pack the header into binary format
        return struct.pack('!BBHII', *header)

    def send_audio(self):
        try:
            with wave.open(self.audio_file, 'rb') as wf:
                frame_rate = wf.getframerate()
                frame_duration = 160 / frame_rate 

                packet_count = 0 
                while True:
                    data = wf.readframes(160)
                    if not data:
                        break

                    # RTP PACKET
                    rtp_header = self.build_rtp_header()
                    rtp_packet = rtp_header + data
                    self.sock.sendto(rtp_packet, (self.remote_ip, self.remote_port))

                    # seq number, timestamp and packet count increment
                    self.sequence_number += 1
                    self.timestamp += 160 
                    packet_count += 1
                    print(f"Sent RTP packet {packet_count}, timestamp {self.timestamp}")
                    time.sleep(frame_duration)

            self.sock.sendto(b"END", (self.remote_ip, self.remote_port))
            print("===========================================")
            print("============== STREAM ENDED ===============")
            print("===========================================\n")
        except Exception as e:
            print(f"Error: {e}")
        finally:
            self.sock.close()

class ReportRTCP:
    def __init__(self, remote_ip, remote_port):
        self.remote_ip = remote_ip
        self.remote_port = remote_port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.packet_count = 0
        self.byte_count = 0
        self.ssrc = random.randint(0, 2**32 - 1)  # Dynamically generate a random SSRC

    def send_report(self):
        while True:
            try:
                # RTCP Sender Report ! * check this first before doing it  https://www4.cs.fau.de/Projects/JRTP/pmt/node83.html
                rtcp_header = struct.pack('!BBH', 0x80, 200, 6)  
                sender_info = struct.pack('!IIIIII', self.ssrc, int(time.time()), 0, self.packet_count, self.byte_count, 0)
                rtcp_packet = rtcp_header + sender_info

                # Send RTCP packet
                self.sock.sendto(rtcp_packet, (self.remote_ip, self.remote_port))
                
                print(f"RTCP Sender Report Sent!")
                                
                time.sleep(5) # send periodically so every 5 seconds (default sip)
            except Exception as e:
                print(f"Error in RTCP Sender: {e}")
                break

def main():
    # audiofile must be in the same folder as sender.py
    audio_file = input("Enter the name of the .wav file to play (e.g., audio.wav): ")

    SendSIP = HandlingSIPinSender(local_ip="127.0.0.1", local_port=5060, remote_ip="127.0.0.1", remote_port=5061)
    sendRTPAudio = HandlingRTPinSender(audio_file=audio_file, remote_ip="127.0.0.1", remote_port=5004)
    sendRTCPReport = ReportRTCP(remote_ip="127.0.0.1", remote_port=5005)

    try:
        # Start SIP handshake
        print("Establishing SIP call...")
        SendSIP.SIP_HANDSHAKE()  
        print("SIP call established.")

        # threading for RTCP report
        rtcp_thread = threading.Thread(target=sendRTCPReport.send_report, daemon=True)
        rtcp_thread.start()


        print(f"Playing audio from file: {audio_file}.")
        sendRTPAudio.send_audio()

    # Error Handling
    except FileNotFoundError: 
        print(f"Error: Audio file '{audio_file}' not found.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        SendSIP.end_call()
        print("The call has been terminated.")

if __name__ == "__main__":
    main()