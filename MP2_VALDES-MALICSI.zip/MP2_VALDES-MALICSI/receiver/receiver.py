import socket
import struct
import time
import threading
import random
import wave
import pyaudio
import uuid

class HandlingSIPinReceiver:
    def __init__(self, local_ip, local_port, remote_ip, remote_port):
        self.local_ip = local_ip
        self.local_port = local_port
        self.remote_ip = remote_ip
        self.remote_port = remote_port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((self.local_ip, self.local_port))
        self.call_id = str(uuid.uuid4()) 

    def checkHandshake(self):
        while True:
            message, addr = self.sock.recvfrom(1024)
            if b"INVITE" in message:
                # decoding the message for sdp parsing
                message_str = message.decode()
                sdp_start = message_str.find("\r\n\r\n") + 4 
                sdp = message_str[sdp_start:]
                
                for line in sdp.splitlines():
                    if line.startswith("c="):
                        self.remote_ip = line.split()[2]  # Extract the IP address
                    elif line.startswith("m="):
                        self.remote_port = int(line.split()[1])  # Extract the port

                # Log the parsed SDP information
                print(f"SDP - Client 2: Remote IP = {self.remote_ip} & Remote Port = {self.remote_port}")

                # SDP Body for 200 OK Response
                sdp_body = f"v=0\r\n"
                sdp_body += f"o=- 0 0 IN IP4 {self.local_ip}\r\n"
                sdp_body += f"s=VoIP Call\r\n"
                sdp_body += f"c=IN IP4 {self.local_ip}\r\n"
                sdp_body += f"t=0 0\r\n"
                sdp_body += f"m=audio {self.local_port} RTP/AVP 0\r\n"
                sdp_body += f"a=rtpmap:0 PCMU/8000\r\n"

                # 200 OK Response
                response = f"SIP/2.0 200 OK\r\n"
                response += f"Via: SIP/2.0/UDP {self.local_ip}:{self.local_port}\r\n"
                response += f"To: <sip:{self.local_ip}:{self.local_port}>\r\n"
                response += f"From: <sip:{self.remote_ip}:{self.remote_port}>\r\n"
                response += f"Call-ID: {self.call_id}\r\n"
                response += "CSeq: 1 200 OK\r\n"
                response += "Content-Type: application/sdp\r\n"
                response += f"Content-Length: {len(sdp_body)}\r\n\r\n"
                response += sdp_body
                self.sock.sendto(response.encode(), addr)

            if b"ACK" in message:
                print("ACK packet received. The call will now start.")
                break

    def sendBYE(self):
        # BYE Message
        ByeMessage = f"BYE sip:{self.remote_ip}:{self.remote_port} SIP/2.0\r\n"
        ByeMessage += f"Via: SIP/2.0/UDP {self.local_ip}:{self.local_port}\r\n"
        ByeMessage += f"To: <sip:{self.remote_ip}:{self.remote_port}>\r\n"
        ByeMessage += f"From: <sip:{self.local_ip}:{self.local_port}>\r\n"
        ByeMessage += f"Call-ID: {self.call_id}\r\n"
        ByeMessage += "CSeq: 2 BYE\r\n"
        ByeMessage += "Content-Length: 0\r\n\r\n"
        self.sock.sendto(ByeMessage.encode(), (self.remote_ip, self.remote_port))
        print("BYE message sent.")
        print("Waiting other client's BYE message...")

        try:
            self.sock.settimeout(5) 
            while True:
                message, addr = self.sock.recvfrom(1024)
                if b"BYE" in message:
                    print("BYE message received! Ending the call.")
                    break
        except socket.timeout:
            print("Timeout! waiting for BYE message from other client.")

        # Close
        self.sock.close()

class HandlingRTPinReceiver:
    def __init__(self, local_port, remote_ip, remote_port):
        self.local_port = local_port
        self.remote_ip = remote_ip
        self.remote_port = remote_port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65536)
        self.sock.bind(("", self.local_port))
        self.ssrc = random.randint(0, 2**32 - 1)  # Generate a random SSRC during initialization

    def ParseRTP(self, data):
        header = struct.unpack('!BBHII', data[:12])
        payload = data[12:] 
        return payload

    def writeAudioFile(self):
        p = pyaudio.PyAudio()
        stream = p.open(format=pyaudio.paInt16, channels=1, rate=8000, output=True)

        with wave.open("received_audio.wav", 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(8000)

            packet_count = 0 
            last_rtcp_time = time.time()  

            try:
                while True:
                    data, _ = self.sock.recvfrom(2048)
                    if not data or data == b"END": 
                        print("===========================================")
                        print("============== STREAM ENDED ===============")
                        print("===========================================\n")
                        break

                    # Parse RTP header
                    payload = self.ParseRTP(data)
                    wf.writeframes(payload)
                    stream.write(payload) # just play the audio

                    packet_count += 1

            except Exception as e:
                print(f"Error: {e}")
            finally:
                self.sock.close()
                stream.stop_stream()
                stream.close()
                p.terminate()

def ParseRTCP(data):
    try:
        rtcp_header = struct.unpack('!BBH', data[:4])
        version = (rtcp_header[0] >> 6) & 0x03
        padding = (rtcp_header[0] >> 5) & 0x01
        report_count = rtcp_header[0] & 0x1F
        packet_type = rtcp_header[1]
        length = rtcp_header[2]
        print("=======================")
        print(f"RTCP Packet Details")
        print(f"  Version: {version}")
        print(f"  Padding: {padding}")
        print(f"  Report Count: {report_count}")
        print(f"  Packet Type: {packet_type}")
        print(f"  Length: {length}")

        if packet_type == 200:  # Sender Report (RFC 3550)
            sender_ssrc = struct.unpack('!I', data[4:8])[0]
            print(f"  Sender SSRC: {sender_ssrc}")
            print("=======================")
        elif packet_type == 201:  # Receiver Report (RFC 3550)
            receiver_ssrc = struct.unpack('!I', data[4:8])[0]
            print(f"  Receiver SSRC: {receiver_ssrc}")
        else:
            print("  Unknown RTCP packet type.")
    except Exception as e:
        print(f"Error parsing RTCP packet: {e}")
        

class HandlingRTCPinReceiver:
    def __init__(self, remote_ip, remote_port):
        self.remote_ip = remote_ip
        self.remote_port = remote_port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("", self.remote_port))
        self.packet_count = 0
        self.running = True 
        self.stop_event = threading.Event()  
        self.ssrc = random.randint(0, 2**32 - 1) 

    def createRTCP(self):
        while self.running:
            try:
                # RTCP Header (RFC 3550)
                version = 2
                padding = 0
                report_count = 0  
                packet_type = 201 
                length = 1  

                # RTCP Header
                rtcp_header = struct.pack('!BBH',
                                          (version << 6) | (padding << 5) | report_count,
                                          packet_type,
                                          length)

                # SSRC of Packet Sender
                ssrc_sender = struct.pack('!I', self.ssrc)

                # Combine header and SSRC to form the RTCP packet
                rtcp_packet = rtcp_header + ssrc_sender

                # Send RTCP packet
                self.sock.sendto(rtcp_packet, (self.remote_ip, self.remote_port))


                print(f"RTCP Receiver Report sent!")
                
                if self.stop_event.wait(5): 
                    break
            except socket.error as e:
                print(f"Socket error in RTCP Receiver: {e}")
                self.running = False 
            except Exception as e:
                print(f"Error in RTCP Receiver: {e}")
                break


    def FindReport(self):
        while self.running:
            try:
                # Listen for any packets
                data, addr = self.sock.recvfrom(1024)
                
                # Parse the received packet
                ParseRTCP(data)
            except socket.error as e:
                if not self.running:  
                    break
                print(f"Socket error in RTCP Receiver: {e}")
                break
            except Exception as e:
                print(f"Error in RTCP Receiver: {e}")
                break

    def stop(self):
        self.running = False
        self.stop_event.set()
        if self.sock:
            self.sock.close() 
            self.sock = None

def main():
    sip_client = HandlingSIPinReceiver(local_ip="127.0.0.1", local_port=5061, remote_ip="127.0.0.1", remote_port=5060)
    rtp_receiver = HandlingRTPinReceiver(local_port=5004, remote_ip="127.0.0.1", remote_port=5005)
    rtcp_receiver = HandlingRTCPinReceiver(remote_ip="127.0.0.1", remote_port=5005)

    try:
        # Receive the call
        print("Waiting for SIP INVITE...")
        sip_client.checkHandshake()
        print("SIP call established.")

        # Start RTCP sender and receiver reports
        rtcp_send_thread = threading.Thread(target=rtcp_receiver.createRTCP, daemon=True)
        rtcp_listen_thread = threading.Thread(target=rtcp_receiver.FindReport, daemon=True)
        rtcp_send_thread.start()
        rtcp_listen_thread.start()

        # Receive RTP audio file
        print("Receiving audio...")
        rtp_receiver.writeAudioFile()
        rtcp_receiver.stop()
        rtcp_send_thread.join()
        rtcp_listen_thread.join()

    except Exception as e:
        print(f"Error: {e}")

    finally:
        sip_client.sendBYE()
        print("The call has been terminated.")

if __name__ == "__main__":
    main()